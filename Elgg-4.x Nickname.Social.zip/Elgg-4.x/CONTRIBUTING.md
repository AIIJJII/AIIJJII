## DISCLAIMERS

 * **SECURITY ISSUES SHOULD BE REPORTED TO security @ elgg . org!** Please do not post any security issues on github.
 * Support requests belong on the [Community site][2]. Tickets with support requests will be closed. 
 * We cannot make any guarantees as to when your ticket will be resolved or your PR merged. 
 * **By submitting a pull request you are agreeing to license the code under a [GPLv2 license][3] and [MIT license][4].**
 * For more information visit http://learn.elgg.org/en/stable/contribute/index.html

 [2]: http://community.elgg.org
 [3]: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 [4]: http://en.wikipedia.org/wiki/MIT_License
