See http://learn.elgg.org/en/stable/contribute/docs.html
