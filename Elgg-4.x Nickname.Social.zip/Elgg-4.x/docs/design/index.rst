Design Docs
###########

Gain a deep understanding of how Elgg works 
and why it's built the way it is.

.. toctree::
   :maxdepth: 1

   actions
   database
   events
   i18n
   amd
   security
   loggable
