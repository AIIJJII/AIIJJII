Developer Guides
################

Customize Elgg's behavior with plugins.

.. toctree::
   :glob:
   :maxdepth: 1
   
   dont-modify-core
   *
