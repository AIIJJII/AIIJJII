Tutorials
#########

Walk through all the required steps in order to customize Elgg.

The instructions are detailed enough that you don't need much previous experience with Elgg.

.. toctree::
   :maxdepth: 1
   
   hello_world
   indexpage
   blog
   wysiwyg
   widget