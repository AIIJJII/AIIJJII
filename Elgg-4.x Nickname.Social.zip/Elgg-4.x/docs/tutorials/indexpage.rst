Customizing the Home Page
#########################

To override the homepage, just override Elgg's ``resources/index`` view  by
creating a file at ``/views/default/resources/index.php``.

Any output from this view will become your new homepage.

You can take a similar approach with any other page in Elgg or official plugins.
