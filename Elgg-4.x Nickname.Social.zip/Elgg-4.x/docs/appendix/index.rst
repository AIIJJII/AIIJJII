Appendix
########

Miscellaneous information about the project.

.. toctree::
   :maxdepth: 2

   upgrade-notes
   faqs
   roadmap
   releases
   support
   history
