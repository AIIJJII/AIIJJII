The Wire
========

Elgg wire plugin "The Wire" is Twitter-style microblogging plugin that allows users to post notes to the wire.
