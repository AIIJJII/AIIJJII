Discussions
===========

Add a forum like place to start a discussion. This feature is mainly meant to used in groups. The group owners can enable/disable this feature 
for their group.

There is a plugin setting to enable global discussions (so outside of a group). This setting is disabled by default but can be enabled by 
a site administrator.

Notifications
-------------

In order to encourage discussion in a group all group members will receive notifications about comments on a discussion topic. This will follow the 
notification preferences of the group member based on the global group preference or the specific group preference for new discussions.
