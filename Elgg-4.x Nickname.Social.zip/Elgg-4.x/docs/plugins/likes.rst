Likes
=====

Allow users to like content on your site. If content supports being likable a 'thumbs up' will appear as a social interaction with this content. 
Liking content will also notify the content owner about the new like. A counter will show next to the like action reporting about the amount of likes the content has.
Clicking on the counter will show a list of users who recently liked the content.

.. note::

   The likes plugin uses the entity capability `likable`. This capability defines if an entity is likable.
