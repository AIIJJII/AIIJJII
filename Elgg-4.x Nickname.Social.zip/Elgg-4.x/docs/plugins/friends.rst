Friends
=======

Being a social network framework Elgg supports relationships between users. 

By default any user can befriend any other user, it's like following the activity of the other user.

After enabling friendship requests as a feature of the Friends plugin, when user A wants to be friends 
with user B, user B has to approve the request. Upon approval user A will be friends with user B and 
user B will be friends with user A.
