Core tasks
##########

Certain tasks surrounding Elgg are reserved for the core developer as they require special permissions.
The guides below show the workflow for these actions.

.. toctree::
   :maxdepth: 1
   :glob:
   
   *
