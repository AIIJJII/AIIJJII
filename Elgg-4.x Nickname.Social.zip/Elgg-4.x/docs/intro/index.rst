Getting Started
###############

Discover if Elgg is right for your community.

.. toctree::
   :maxdepth: 1
  
   /plugins/index
   license
   install
   development
   elgg-cli
