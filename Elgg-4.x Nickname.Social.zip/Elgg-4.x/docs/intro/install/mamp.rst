:orphan:

Installing Elgg on MAMP
#######################

Follow the :doc:`standard installation instructions <../install>`.

On certain versions of MAMP, Elgg will either fail to install or have
intermittent problems while running.

This is a known issue with MAMP and is related to the Zend Optimizer.
Until Zend/MAMP have resolved this issue it is recommended that you
**turn off the Zend Optimizer** in your PHP settings.
