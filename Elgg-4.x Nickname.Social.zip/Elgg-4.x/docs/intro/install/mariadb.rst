:orphan:

Installing Elgg on MariaDB
##########################

You should be able to follow the :doc:`standard installation instructions <../install>`,
since this DBMS is supposed to be a drop-in replacement for MySQL.

Let us know how it goes!

Here is some historical community discussion, for reference:
https://community.elgg.org/discussion/view/1455994/alternative-dbmss

