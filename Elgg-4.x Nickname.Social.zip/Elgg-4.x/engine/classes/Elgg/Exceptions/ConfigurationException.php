<?php

namespace Elgg\Exceptions;

/**
 * A generic parent class for Configuration exceptions
 *
 * @since 4.0
 */
class ConfigurationException extends Exception {

}
