<?php

namespace Elgg\Exceptions;

/**
 * A parameter is invalid
 *
 * @since 4.0
 */
class InvalidParameterException extends Exception {

}
