<?php

namespace Elgg\Exceptions;

/**
 * A generic parent class for cron exceptions
 *
 * @since 4.0
 */
class CronException extends Exception {

}
