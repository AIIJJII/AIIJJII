<?php

namespace Elgg\Exceptions\Configuration;

/**
 * Could not register a new user for whatever reason
 *
 * @since 4.0
 */
class RegistrationException extends InstallationException {

}
