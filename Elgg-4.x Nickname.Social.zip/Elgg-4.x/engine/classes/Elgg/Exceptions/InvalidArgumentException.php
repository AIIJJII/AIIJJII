<?php

namespace Elgg\Exceptions;

/**
 * Base exception of invalid argument exceptions in the Elgg system
 *
 * @since 4.0
 */
class InvalidArgumentException extends \InvalidArgumentException {

}
