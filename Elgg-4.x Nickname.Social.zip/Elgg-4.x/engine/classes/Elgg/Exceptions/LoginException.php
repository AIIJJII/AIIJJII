<?php

namespace Elgg\Exceptions;

/**
 * Generic parent class for login exceptions
 *
 * @since 4.0
 */
class LoginException extends \Exception {

}
