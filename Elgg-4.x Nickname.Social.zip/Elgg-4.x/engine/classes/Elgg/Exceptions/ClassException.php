<?php

namespace Elgg\Exceptions;

/**
 * A generic parent class for Class exceptions
 *
 * @since 4.0
 */
class ClassException extends Exception {

}
