<?php

namespace Elgg\Export;

/**
 * Access collection export
 *
 * @property int    $id
 * @property string $type
 * @property string $subtype
 * @property string $name
 * @property int    $owner_guid
 */
class AccessCollection extends Data {

}
