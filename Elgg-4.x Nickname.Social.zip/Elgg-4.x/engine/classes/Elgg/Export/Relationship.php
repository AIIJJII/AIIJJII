<?php

namespace Elgg\Export;

/**
 * Relationship export
 *
 * @property int    $id
 * @property int    $subject_guid
 * @property int    $object_guid
 * @property string $relationship
 */
class Relationship extends Data {

}
